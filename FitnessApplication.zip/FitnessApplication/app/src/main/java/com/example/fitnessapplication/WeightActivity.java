package com.example.fitnessapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class WeightActivity extends AppCompatActivity {
    DatabaseHelperWeights myDb2;
    Button addWeightBTN, viewAllBTN, delete_button;
    Spinner weight_spinner, exercise_spinner, reps_spinner, sets_spinner;
    EditText editTextName2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);

        myDb2 = new DatabaseHelperWeights(this);
        addWeightBTN = findViewById(R.id.addweight_button);
        viewAllBTN = findViewById(R.id.vieww_button);
        delete_button = findViewById(R.id.delete_button2);
        weight_spinner = findViewById(R.id.weight_spinner);
        exercise_spinner = findViewById(R.id.exercise_spinner);
        reps_spinner = findViewById(R.id.reps_spinner);
        sets_spinner = findViewById(R.id.sets_spinner);
        editTextName2 = findViewById(R.id.editTextName2);

        ArrayAdapter<String> myAdapter2 = new ArrayAdapter<>(WeightActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.exercise));
        myAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        exercise_spinner.setAdapter(myAdapter2);

        ArrayAdapter<String> myAdapter3 = new ArrayAdapter<>(WeightActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.weight));
        myAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        weight_spinner.setAdapter(myAdapter3);

        ArrayAdapter<String> myAdapter4 = new ArrayAdapter<>(WeightActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.reps));
        myAdapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        reps_spinner.setAdapter(myAdapter4);

        ArrayAdapter<String> myAdapter5 = new ArrayAdapter<>(WeightActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.sets));
        myAdapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sets_spinner.setAdapter(myAdapter5);
        AddData();
        ViewAll();
    }

    public void AddData() {
        addWeightBTN.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        boolean isInserted = false;

                        try {
                            isInserted= myDb2.insertData(editTextName2.getText().toString(),
                                    exercise_spinner.getSelectedItem().toString(),
                                    weight_spinner.getSelectedItem().toString(),
                                    reps_spinner.getSelectedItem().toString(),
                                    sets_spinner.getSelectedItem().toString());
                        } catch (Exception e){}
                        if (isInserted == true) {
                            Toast.makeText(WeightActivity.this, "Data Inserted", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(WeightActivity.this, "Data Not Inserted", Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );

    }

    public void ViewAll() {
        viewAllBTN.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Cursor res = myDb2.getAllData();
                        if (res.getColumnCount() == 0) {
                            showMessage("Error", "No data found");
                            return;
                        } else {
                            StringBuffer buffer = new StringBuffer();
                            while (res.moveToNext()) {
                                buffer.append("Name : " + res.getString(0) + "\n");
                                buffer.append("Exercise : " + res.getString(1) + "\n");
                                buffer.append("Weight : " + res.getString(2) + "\n");
                                buffer.append("Reps : " + res.getString(3) + "\n");
                                buffer.append("Sets : " + res.getString(4) + "\n\n");
                            }
                            showMessage("Data", buffer.toString());
                        }
                    }
                }
        );
    }

    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
        DeleteData();
    }

    public void DeleteData() {
        delete_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Integer deletedRows = myDb2.deleteData(editTextName2.getText().toString());
                        if (deletedRows > 0) {
                            Toast.makeText(WeightActivity.this, deletedRows.toString() + " Rows Deleted", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(WeightActivity.this, "Data Not Deleted", Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
    }
}