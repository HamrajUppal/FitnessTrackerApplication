package com.example.fitnessapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
        Button reg_button;
        Spinner gender_spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        TextView username2 = (TextView) findViewById(R.id.editTextTextPersonName3);
        TextView password2 = (TextView) findViewById(R.id.editTextTextPassword);
        Button regBTN = (Button) findViewById(R.id.reg_button);

        regBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (username2.getText().toString().equals("") && password2.getText().toString().equals(""));
                Toast.makeText(RegisterActivity.this, "Registered New Account", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

