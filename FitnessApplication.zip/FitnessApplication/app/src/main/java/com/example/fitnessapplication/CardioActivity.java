package com.example.fitnessapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class CardioActivity extends AppCompatActivity {
    Button addCardioBTN, viewAllBTN, delete_button;
    Spinner cardio_spinner, duration_spinner;
    EditText editTextTextPersonName, editTextName, edittext_distance;
    DatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cardio);


        myDb = new DatabaseHelper(this);
        addCardioBTN = findViewById(R.id.addcardio_button);
        viewAllBTN = findViewById(R.id.view_button);
        edittext_distance = findViewById(R.id.edittext_distance);
        editTextName = findViewById(R.id.editTextName);
        cardio_spinner = findViewById(R.id.cardio_spinner);
        duration_spinner = findViewById(R.id.duration_spinner);
        delete_button = findViewById(R.id.delete_button);

        ArrayAdapter<String> myAdapter1 = new ArrayAdapter<String>(CardioActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.duration));
        myAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        duration_spinner.setAdapter(myAdapter1);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(CardioActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.machines));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cardio_spinner.setAdapter(myAdapter);
        AddData();

    }

    public void AddData() {
        addCardioBTN.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        boolean isInserted = myDb.insertData(editTextName.getText().toString(),
                                cardio_spinner.getSelectedItem().toString(),
                                duration_spinner.getSelectedItem().toString(),
                                edittext_distance.getText().toString());
                        if (isInserted == true) {
                            Toast.makeText(CardioActivity.this, "Data Inserted", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(CardioActivity.this, "Data Not Inserted", Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
        ViewAll();
    }

    public void ViewAll() {
        viewAllBTN.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Cursor res = myDb.getAllData();
                        if (res.getColumnCount() == 0) {
                            showMessage("Error", "No data found");
                            return;
                        } else {
                            StringBuffer buffer = new StringBuffer();
                            while (res.moveToNext()) {
                                buffer.append("Name : " + res.getString(0) + "\n");
                                buffer.append("Machine : " + res.getString(1) + "\n");
                                buffer.append("Distance : " + res.getString(2) + "\n");
                                buffer.append("Duration : " + res.getString(3) + "\n\n");
                            }
                            showMessage("Data", buffer.toString());
                        }
                    }
                }
        );
    }

    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
        DeleteData();
    }
    public void DeleteData() {
        delete_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Integer deletedRows = myDb.deleteData(editTextName.getText().toString());
                        if (deletedRows > 0) {
                            Toast.makeText(CardioActivity.this, deletedRows.toString() + " Rows Deleted", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(CardioActivity.this, "Data Not Deleted", Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
    }
}




