package com.example.fitnessapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SigninActivity extends AppCompatActivity {

    Button sign_in_button, register_button;
    EditText editTextPersonNameSignInUsername, editTextTextPassword2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        TextView username = (TextView) findViewById(R.id.editTextPersonNameSignInUsername);
        TextView password = (TextView) findViewById(R.id.editTextTextPassword2);
        Button loginBTN = (Button) findViewById(R.id.sign_in_button);

        loginBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (username.getText().toString().equals("") && password.getText().toString().equals(""));
                Toast.makeText(SigninActivity.this, "Log in Successful", Toast.LENGTH_SHORT).show();
            }
        });

            Button regBTN = findViewById(R.id.register_button);

        regBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SigninActivity.this,RegisterActivity.class));
            }
        });
    }
}